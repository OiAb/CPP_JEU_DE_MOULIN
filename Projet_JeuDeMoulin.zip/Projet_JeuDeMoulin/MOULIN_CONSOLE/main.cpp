#include <iostream>
#include<SDL.h>
#include <windows.h>
#include <cstdlib>
#include<stdio.h>
#include <conio.h>
#include <string.h>
#include <vector>
#include <algorithm>
#include "Choice.h"
#include "Strategie.h"
using namespace std;

int main(int argv,char** argc)
{
   int i=0;Choice c;int x,continuer=1;
   Strategie s(c);
    s.Menu();
    cin>>x;
    while(continuer){
    switch(x){
      case 1:
      continuer=0;
      ;break;
      case 2:
        exit(EXIT_FAILURE);break;
    }}
    continuer=1;
    system("cls");
    s.MenuLevel();
    cin>>x;
    while(continuer){
    switch(x){
      case 1:
      continuer=0;
      goto easy;break;
      case 2:
      continuer=0;
      goto hard;break;
    }}
    easy:
    system("cls");
    s.CreateTable();
    s.CreateColonneeLignee();
    s.AfficherTableau();
    role:
    i++;
    s.RandomPosition();
    s.RemplirTableauMin();
    s.Moulin();
    cout<<"Min ! Choisissez une position de pion (par exemple : 1 1)"<<endl;
    s.lirePosition();
    s.RemplirTableauMax();
    s.Moulin();
    while(i<9) goto role;
    tour:
    s.CompteurPion();
    if(s.SauterMax()&&s.SauterMin()){
    s.RandomPositionDeplacer();s.Moulin();s.DeplacementVulnerable();
    cout<<"Min ! vous avez depose les neuf pions !"<<endl;
    s.lirePositionDeplacer();s.Moulin();s.DeplacementVulnerable();
    goto tour;
    }
    else if(s.SauterMax()==0&&s.SauterMin()){
    s.RandomPositionDeplacer();s.Moulin();s.DeplacementVulnerable();
    cout<<"Min ! Il Vous reste 3 pions ! Choisissez une position de pion a deplacer (par exemple : 1 1)"<<endl;
    s.lirePosition();
    s.PositionDeplacer();s.Moulin();s.DeplacementVulnerable();
    goto tour;}
    else if(s.SauterMax()&&s.SauterMin()==0){
    s.RandomPosition();
    s.RandomDeplacer();s.Moulin();s.DeplacementVulnerable();
    cout<<"Min ! vous avez depose les neuf pions !"<<endl;
    s.lirePositionDeplacer();s.Moulin();s.DeplacementVulnerable();
    goto tour;
    }
    else if(s.SauterMax()==0&&s.SauterMin()==0){
    tour1:
    s.RandomPosition();
    s.RandomDeplacer();
    s.Moulin();s.DeplacementVulnerable();
    cout<<"Min ! Choisissez une position de pion a deplacrt (par exemple : 1 1)"<<endl;
    s.lirePosition();
    s.PositionDeplacer();
    s.Moulin();s.DeplacementVulnerable();
    goto tour1;
     }
    hard:
    system("cls");
    cout << "1. MiniMax" << endl << "2. Alpha-Beta" << endl;
	cout << "Choisir la strategie a utiliser : " << endl;
    c.lire();
    s.CreateTable();
    s.CreateColonneeLignee();
    s.AfficherTableau();
    return 0;
}
