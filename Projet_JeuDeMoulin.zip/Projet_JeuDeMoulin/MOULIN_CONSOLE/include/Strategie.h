#ifndef STRATEGIE_H
#define STRATEGIE_H
#include "Choice.h"

class Strategie
{
    public:
        Strategie(Choice c);
        void Color(int couleurDuTexte,int couleurDeFond);
        void algorithme();
        void MiniMax();
        void AlphaBeta();
        void CreateTable();
        void Menu();
        void MenuLevel();
        void AfficherTableau();
        void lirePosition();
        void lirePositionDeplacer();
       void PositionDeplacer();
        void RemplirTableauMax();
        void RemplirTableauMin();
        void RandomPosition();
        void RandomDeplacer();
        void RandomPositionDeplacer();
        void RandomDeplacerPionAdjacent(char pos,int i,int j);
        void DeplacerPionAdjacent(char pos,int i,int j);
        void DeplacementVulnerable();
        void Moulin();
        void RetirerAdversaire(int a,int b);
        bool AncienMoulinColonne(int i);
        bool AncienMoulinLigne(int i);
        void CompteurPion();
        void CreateColonneeLignee();
        bool SauterMax();
        bool SauterMin();
    protected:

    private:
    int maxi=0;int mini=0;
    int lignee[1][8];int colonnee[1][8];
    int cm=0,cM=0;
    char tab[37][80];
    char tab1[37][80];
    bool VerifierPosition(int i,int j);
    Choice choice;
    int ligne,colonne;
};

#endif // STRATEGIE_H
