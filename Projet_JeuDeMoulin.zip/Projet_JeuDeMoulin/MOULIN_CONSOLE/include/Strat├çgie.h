#ifndef STRAT�GIE_H
#define STRAT�GIE_H


class Strat�gie
{
    public:
        Strat�gie();
        virtual ~Strat�gie();

    protected:

    private:
};

#endif // STRAT�GIE_H
