#include "Strat�gie.h"

Strat�gie::Strat�gie()
{
    //ctor
}

Strat�gie::~Strat�gie()
{
    //dtor
}
