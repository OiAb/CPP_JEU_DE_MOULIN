#ifndef STRATEGIE_H
#define STRATEGIE_H
#include "Choice.h"
typedef struct Etat
{
 char tableau[37][80];
}Etat;
typedef struct Noeud
{
 Etat  etat;
 Noeud* suivant;
}Noeud;
typedef struct Liste
{
    Noeud* debut;
}Liste;

class Strategie
{
    public:
        Strategie(Choice c);
        void Color(int couleurDuTexte,int couleurDeFond);
        void algorithme();
        void MiniMax(Etat e);
        void AlphaBeta();
        void CreateTable();
        void Menu();
        void MenuLevel();
        void AfficherTableau();
        void lirePosition();
        void lirePositionDeplacer();
        void PositionDeplacer();
        void RemplirTableauMax();
        void RemplirTableauMin();
        void RandomPosition();
        void RandomDeplacer();
        void RandomPositionDeplacer();
        void RandomDeplacerPionAdjacent(char pos,int i,int j);
        void DeplacerPionAdjacent(char pos,int i,int j);
        void DeplacementVulnerable();
        void Moulin();
        void CreateAvoidMoulin();
        void RetirerAdversaire(int a,int b);
        bool AncienMoulinColonne(int i);
        bool AncienMoulinLigne(int i);
        void CompteurPion();
        void CreateColonneeLignee();
        bool SauterMax();
        bool SauterMin();
        int Vide(Liste listeNoeuds);
        void extraire(Etat* e, Liste listeNoeuds);
        void Inserer(Etat actuel,Liste* listeNoeuds);
        void hLigne(Etat e1,int i,int j);
        void hColonne(Etat e1,int i,int j);
        void RandomPositionDeffenseAttaque();
    protected:

    private:
    int maxi=0;int mini=0;
    int lignee[1][8];int colonnee[1][8];
    int cm=0,cM=0;
    char tab[37][80];
    char tab1[37][80];
    bool VerifierPosition(int i,int j);
    Choice choice;
    int ligne,colonne;
    int l=0,col=0,hi,hj;
    int IAi=10,IAj=10;
};

#endif // STRATEGIE_H
