#ifndef CHOICE_H
#define CHOICE_H


class Choice
{
    public:
        Choice(int i=0);
        void lire();
        int retournerType();
    protected:

    private:
    bool Verifier(int i);
    int type;
};

#endif // CHOICE_H
